app_name = "amb_w_spc"
app_title = "amb_w_spc"
app_publisher = "AMB-Wellness"
app_description = "AMB-W SPC on ERPNEXT"
app_email = "fcrm@amb-wellness.com"
app_license = "mit"

# Apps
# ------------------

# required_apps = []

# Each item in the list will be shown as an app in the apps page
# add_to_apps_screen = [
# 	{
# 		"name": "amb_w_spc",
# 		"logo": "/assets/amb_w_spc/logo.png",
# 		"title": "amb_w_spc",
# 		"route": "/amb_w_spc",
# 		"has_permission": "amb_w_spc.api.permission.has_app_permission"
# 	}
# ]

# Includes in <head>
# ------------------

# include js, css files in header of desk.html
# app_include_css = "/assets/amb_w_spc/css/amb_w_spc.css"
# app_include_js = "/assets/amb_w_spc/js/amb_w_spc.js"

# include js, css files in header of web template
# web_include_css = "/assets/amb_w_spc/css/amb_w_spc.css"
# web_include_js = "/assets/amb_w_spc/js/amb_w_spc.js"

# include custom scss in every website theme (without file extension ".scss")
# website_theme_scss = "amb_w_spc/public/scss/website"

# include js, css files in header of web form
# webform_include_js = {"doctype": "public/js/doctype.js"}
# webform_include_css = {"doctype": "public/css/doctype.css"}

# include js in page
# page_js = {"page" : "public/js/file.js"}

# include js in doctype views
# doctype_js = {"doctype" : "public/js/doctype.js"}
# doctype_list_js = {"doctype" : "public/js/doctype_list.js"}
# doctype_tree_js = {"doctype" : "public/js/doctype_tree.js"}
# doctype_calendar_js = {"doctype" : "public/js/doctype_calendar.js"}

# Svg Icons
# ------------------
# include app icons in desk
# app_include_icons = "amb_w_spc/public/icons.svg"

# Home Pages
# ----------

# application home page (will override Website Settings)
# home_page = "login"

# website user home page (by Role)
# role_home_page = {
# 	"Role": "home_page"
# }

# Generators
# ----------

# automatically create page for each record of this doctype
# website_generators = ["Web Page"]

# automatically load and sync documents of this doctype from downstream apps
# importable_doctypes = [doctype_1]

# Jinja
# ----------

# add methods and filters to jinja environment
# jinja = {
# 	"methods": "amb_w_spc.utils.jinja_methods",
# 	"filters": "amb_w_spc.utils.jinja_filters"
# }

# Installation
# ------------

# before_install = "amb_w_spc.install.before_install"
after_install = "amb_w_spc.post_install.run"

# Uninstallation
# ------------

# before_uninstall = "amb_w_spc.uninstall.before_uninstall"
# after_uninstall = "amb_w_spc.uninstall.after_uninstall"

# Integration Setup
# ------------------
# To set up dependencies/integrations with other apps
# Name of the app being installed is passed as an argument

# before_app_install = "amb_w_spc.utils.before_app_install"
# after_app_install = "amb_w_spc.utils.after_app_install"

# Integration Cleanup
# -------------------
# To clean up dependencies/integrations with other apps
# Name of the app being uninstalled is passed as an argument

# before_app_uninstall = "amb_w_spc.utils.before_app_uninstall"
# after_app_uninstall = "amb_w_spc.utils.after_app_uninstall"

# Desk Notifications
# ------------------
# See frappe.core.notifications.get_notification_config

# notification_config = "amb_w_spc.notifications.get_notification_config"

# Permissions
# -----------
# Permissions evaluated in scripted ways

# permission_query_conditions = {
# 	"Event": "frappe.desk.doctype.event.event.get_permission_query_conditions",
# }
#
# has_permission = {
# 	"Event": "frappe.desk.doctype.event.event.has_permission",
# }

# Document Events
# ---------------
# Hook on document methods and events

# doc_events = {
# 	"*": {
# 		"on_update": "method",
# 		"on_cancel": "method",
# 		"on_trash": "method"
# 	}
# }

# Scheduled Tasks
# ---------------

# scheduler_events = {
# 	"all": [
# 		"amb_w_spc.tasks.all"
# 	],
# 	"daily": [
# 		"amb_w_spc.tasks.daily"
# 	],
# 	"hourly": [
# 		"amb_w_spc.tasks.hourly"
# 	],
# 	"weekly": [
# 		"amb_w_spc.tasks.weekly"
# 	],
# 	"monthly": [
# 		"amb_w_spc.tasks.monthly"
# 	],
# }

# Testing
# -------

# before_tests = "amb_w_spc.install.before_tests"

# Overriding Methods
# ------------------------------
#
# override_whitelisted_methods = {
# 	"frappe.desk.doctype.event.event.get_events": "amb_w_spc.event.get_events"
# }
#
# each overriding function accepts a `data` argument;
# generated from the base implementation of the doctype dashboard,
# along with any modifications made in other Frappe apps
# override_doctype_dashboards = {
# 	"Task": "amb_w_spc.task.get_dashboard_data"
# }

# exempt linked doctypes from being automatically cancelled
#
# auto_cancel_exempted_doctypes = ["Auto Repeat"]

# Ignore links to specified DocTypes when deleting documents
# -----------------------------------------------------------

# ignore_links_on_delete = ["Communication", "ToDo"]

# Request Events
# ----------------
# before_request = ["amb_w_spc.utils.before_request"]
# after_request = ["amb_w_spc.utils.after_request"]

# Job Events
# ----------
# before_job = ["amb_w_spc.utils.before_job"]
# after_job = ["amb_w_spc.utils.after_job"]

# User Data Protection
# --------------------

# user_data_fields = [
# 	{
# 		"doctype": "{doctype_1}",
# 		"filter_by": "{filter_by}",
# 		"redact_fields": ["{field_1}", "{field_2}"],
# 		"partial": 1,
# 	},
# 	{
# 		"doctype": "{doctype_2}",
# 		"filter_by": "{filter_by}",
# 		"partial": 1,
# 	},
# 	{
# 		"doctype": "{doctype_3}",
# 		"strict": False,
# 	},
# 	{
# 		"doctype": "{doctype_4}"
# 	}
# ]

# Authentication and authorization
# --------------------------------

# auth_hooks = [
# 	"amb_w_spc.auth.validate"
# ]

# Automatically update python controller files with type annotations for this app.
# export_python_type_annotations = True

# default_log_clearing_doctypes = {
# 	"Logging DocType Name": 30  # days to retain logs
# }

