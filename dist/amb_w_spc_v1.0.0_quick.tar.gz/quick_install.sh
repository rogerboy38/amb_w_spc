#!/bin/bash
echo "🚀 AMB W SPC Quick Install"
pip install -r requirements.txt
echo "✅ Dependencies installed"
echo "📝 Run 'bench get-app .' from your Frappe bench to complete installation"
